
fixInstanceMethodReplace('MPFeedAdViewModel','cellHeight',function(instance, originInvocation, originArguments){
var isRcmdCollectionType = runInstanceWithNoParamter(instance,"isRcmdCollectionType")
if (isRcmdCollectionType == true) {
    var deviceWidth = runClassMethod('MPDevice', 'width',[])
    var imageWidth = (deviceWidth - 15) / 2.0
    var totalHeight = imageWidth * (2.0 /3.0) + 92
    return totalHeight
} else  {
    return runInvocation(originInvocation)
}
});
